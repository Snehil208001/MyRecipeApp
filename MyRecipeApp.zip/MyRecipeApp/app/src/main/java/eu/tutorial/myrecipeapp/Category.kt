package eu.tutorial.myrecipeapp

data class Category(val idCategory:String,
    val strCategory:String,
    val strCategoryThumb:String,
    val strCategoryDescription: String

)

data class catergoriesResponse(val category: List<Category>)