package eu.tutorial.myrecipeapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

// Retrofit setup
private val retrofit = Retrofit.Builder()
    .baseUrl("https://www.themealdb.com/api/json/v1/1/") // Added "https://"
    .addConverterFactory(GsonConverterFactory.create())
    .build()

val recipeService = retrofit.create(ApiService::class.java)

interface ApiService {
    @GET("categories.php") // Correct endpoint
    suspend fun getCategories(): CategoriesResponse
}

// ✅ Properly defined data class
data class CategoriesResponse(
    val categories: List<Category>
)
